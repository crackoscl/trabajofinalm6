from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Administradores(models.Model):
    nombre = models.CharField(max_length=50)
    correo = models.EmailField(max_length=254)
    clave = models.CharField(max_length=50)
    
class Pacientes(models.Model):
    nombre = models.CharField(max_length=100)
    correo = models.EmailField(max_length=200)
    clave = models.CharField(max_length=50, default='123456')
    rut = models.CharField(max_length=10)
    edad = models.IntegerField()
    fecha = models.DateField()
    direccion = models.CharField(max_length=150)
    ocupacion = models.CharField(max_length=150, default='influencer')
    telefono = models.CharField(max_length=20)
    foto = models.CharField(max_length=65535, default='complete info')
    resumen= models.TextField(default='complete la info')
    educacion=models.TextField(default='complete la info')
    historial = models.TextField(default='complete la info')
    class Meta:
        ordering = ['id']
    
    def __str__(self):
        return self.nombre

class Perfil(models.Model):

    usuario = models.OneToOneField(User, on_delete = models.CASCADE)
    descripcion = models.CharField(max_length=70)
    nacionalidad = models.CharField(max_length=100)
    altura = models.DecimalField(max_digits=4, decimal_places=1)
    peso = models.DecimalField(max_digits=4, decimal_places=1)
    direccion = models.CharField(max_length=300)
    codigo_postal = models.CharField(max_length=20)
    archivo_foto = models.CharField(max_length=400, default="sin asignar")
    rol = models.CharField(max_length=50, default="sin asignar")

    def __str__(self):
        return self.usuario.username + " --> " + self.rol
   
class Examenes(models.Model):
    nombre = models.CharField(max_length=50)
    valor = models.CharField(max_length=50)
    fecha = models.DateField()
    observaciones = models.CharField(max_length=250)
    paciente = models.ForeignKey(Pacientes, on_delete=models.CASCADE)
    
    class Meta:
        ordering = ['id']

